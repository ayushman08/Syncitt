
import React, { Component } from 'react';
import { connect } from 'react-redux';
import {
    Image,
    StyleSheet,
    View,
    Text,
    Button,
    TouchableOpacity,
    Alert,
    Platform,
    TextInput,
    ScrollView,
    FlatList,
    AsyncStorage
} from 'react-native';

import {
    globalSearch,
} from "../../Action/ActionCreators";

import {

    showLoading,
    resetState,
} from "./SearchScreenAction";

import { Actions } from 'react-native-router-flux';
import CommonStyles from '../../CommonStyle/CommonStyle';
import Colors from '../../Constants/Colors';
import Strings from '../../Constants/Strings';
import ImagePath from '../../Constants/ImagesPath';
import SearchScreenStyle from './SearchScreenStyle';
import listData from '../../../data';
import { Dropdown } from 'react-native-material-dropdown';
import { CardView } from '../CommonComponent/CardView';
let ref;
class SearchScreen extends Component {
    constructor() {
        super();
        ref = this;
        this.state = {
            searchText:'',
            searchData:{},
        };
    }

    componentWillReceiveProps(nextProps) {

    }

    componentDidUpdate() {
        this.onGetSearchSuccess();
    }

    componentWillUnmount() {

    }

    closeNotifications() {
        Actions.popTo('Dashboard');
    }

    callSearchGlobal() {

        AsyncStorage.getItem("SyncittUserInfo").then((value) => {
            if (value) {

                var userData = JSON.parse(value);
                var authToken = userData.token;
                var postData = {text: this.state.searchText}
                this.props.showLoading();
                this.props.globalSearch(authToken, postData);
            }
        }).done();

    }

    onGetSearchSuccess() {

        if (this.props.searchScreenReducer.globalSearchRes != '') {
            if (this.props.searchScreenReducer.globalSearchRes.code == 200) {
                this.setState({ searchData: this.props.searchScreenReducer.globalSearchRes.data });
                
            }
            else {
                alert(this.props.searchScreenReducer.globalSearchRes.message);
            }
            this.props.resetState();
        }

    }
    onSearchTextChange(text){
        this.setState({searchText:text});
    }

    navBar() {
        return (
            <View style={CommonStyles.navBarMainView}>
                <Image source={ImagePath.HEADER_BG} style={CommonStyles.navBarMainView} />
                <View style={SearchScreenStyle.searchViewStyle}>
                    <Image source={ImagePath.SEARCH_ICON} style={SearchScreenStyle.searchImageStyle} />
                
                    <TextInput
                        placeholder={Strings.SEARCH_ANYTHING}
                        underlineColorAndroid={Colors.TRANSPARENT}
                        style={SearchScreenStyle.searchTextInputStyle}
                        onChangeText={this.onSearchTextChange.bind(this)}
                        value={this.state.searchText}
                        returnKeyType='search'
                        onSubmitEditing={this.callSearchGlobal.bind(this)}
                        />
                
                <TouchableOpacity onPress={() => this.closeNotifications()}>
                    <Image source={ImagePath.DRAWER_CROSS_ICON} style={SearchScreenStyle.navRightImageView} />
                </TouchableOpacity>
                </View>
            </View>
        );
    }


    renderItem({ item, index }) {
 
       return (

            <CardView>
                {
                    <View style={SearchScreenStyle.listMainContainerStyle}>                   
                          <View style={SearchScreenStyle.propertyTitleViewStyle}>
                              <Text style={SearchScreenStyle.propertyTitleTextStyle}>{item.address}</Text>
                          </View>
                          <View style={SearchScreenStyle.propetySubTitleViewStyle}>
                              <Text style={SearchScreenStyle.propertySubTitleTextStyle}>{item.description}</Text>               
                          </View>
                      </View>
                  
                   
                }
            </CardView>

        );
    }


    render() {
        console.log('search in render= ',JSON.stringify(this.state.searchData.propertyData));
        return (
            <View>
                {this.navBar()}
                
                {
                    this.state.searchData.propertyData?
                    <View >
                       
                        <View>
                            <Text style={{fontSize:16,padding:15}}>Properties</Text>
                        </View>
                        <FlatList
                            data={this.state.searchData.propertyData}
                            renderItem={this.renderItem}
                            extraData={this.state}
                        />
                    </View>:null
                }
             

            </View>
        );
    }
}

function mapStateToProps(state) {
    console.log('search screen mapStateToProps= ', JSON.stringify(state));
    return {
        searchScreenReducer: state.searchScreenReducer
    }
}

export default connect(
    mapStateToProps,
    {
        globalSearch,
        showLoading,
        resetState,
    }

)(SearchScreen);

