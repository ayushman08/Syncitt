
import {
    StyleSheet,
    Platform,
    Dimensions
} from 'react-native';
import Colors from '../../Constants/Colors';
const window = Dimensions.get('window');
export default StyleSheet.create({

    searchViewStyle: {
        position: 'absolute',
        flexDirection: 'row',
        justifyContent: 'space-between',
        height: 38,
        borderBottomWidth: 1,
        borderColor: Colors.ADD_PROPERTY_INPUT_VIEW_COLOR,
        marginTop: 15,
        left: 20,
        right: 20,
        bottom: 15,
    },
    searchImageStyle: {
        margin: 1
    },
    searchTextInputStyle: {
        position: 'absolute',
        color: Colors.FILTER_TEXT_VIEW_COLOR,
        fontSize: 14,
        textAlign:'left',
        left: 30,
        right: 30,
    },
    navRightImageView: {
        position: 'absolute',
        right: 1,
        bottom: 15,
    },
    listMainContainerStyle: {
        marginTop: 10,
        marginBottom:20,
        backgroundColor: Colors.WHITE,

    },
    propertyTitleViewStyle: {
        marginTop: 10,
        paddingLeft: 20,
        paddingRight: 20,
     
      
    },
    propertyTitleTextStyle: {

        color: Colors.PROPERTY_TITLE_COLOR,
        fontWeight: '600',
        fontSize: 18
    },
    propetySubTitleViewStyle: {
        marginTop: 10,
        paddingLeft: 20,
        paddingRight: 20,
      
    },
    propertySubTitleTextStyle: {

        color: Colors.PROPERTY_TITLE_COLOR,
        fontSize: 14,
        marginTop: 12,
      
    
      },

});