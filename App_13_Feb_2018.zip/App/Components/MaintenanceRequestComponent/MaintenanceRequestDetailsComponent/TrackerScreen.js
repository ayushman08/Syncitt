import React, { Component } from 'react';
import {
    Image,
    StyleSheet,
    View,
    Text,
    Button,
    TouchableOpacity,
    Alert,
    Platform,
    TextInput,
    ScrollView,
    FlatList,
} from 'react-native';
import { Actions } from 'react-native-router-flux';
import Colors from '../../../Constants/Colors';
import Strings from '../../../Constants/Strings';
import ImagePath from '../../../Constants/ImagesPath';
import TrackerScreenStyle from './TrackerScreenStyle';
import listData from '../../../../data';
import CommonStyles from '../../../CommonStyle/CommonStyle';
let contextRef;

class TrackerScreen extends Component {
    constructor() {
        super();
        this.state = {
            trackerData: {},
        };
        contextRef = this;
    }

    componentWillReceiveProps(nextProps) {

    }

    componentDidUpdate() {

    }

    componentWillUnmount() {

    }
    componentWillMount() {
        this.setState({ trackerData: this.props.reqDetailData });
        //console.log('req_status'+JSON.stringify(this.props.reqDetailData.req_status))
    }


    render() {

        return (

            <ScrollView contentContainerStyle={TrackerScreenStyle.scrollviewContainerStyle}>
                <View style={TrackerScreenStyle.mainContainerStyle}>
                    <View style={TrackerScreenStyle.leftmainViewContainer}>
                        <View style={TrackerScreenStyle.leftViewContainerStyle}>
                            <View style={TrackerScreenStyle.lineViewStyle} />

                            {this.state.trackerData.req_status == 5 ?
                                <View style={TrackerScreenStyle.leftFirstBlueViewStyle} >
                                    <Image source={ImagePath.TRACKER_CONFIRMED} />
                                </View>
                                : <View style={TrackerScreenStyle.leftFirstViewStyle} >
                                    <Image source={ImagePath.TRACKER_CONFIRMED} />
                                </View>
                            }

                            {this.state.trackerData.req_status == 4 ?
                                <View style={{ position: 'absolute', marginTop: 125, justifyContent: 'center', backgroundColor: Colors.SKY_BLUE_BUTTON_BACKGROUND, borderRadius: 100, borderWidth: 1, borderColor: 'grey', padding: 10 }} >
                                    <Image source={ImagePath.TRACKER_COMPLETED} />
                                </View> :
                                <View style={{ position: 'absolute', marginTop: 125, justifyContent: 'center', backgroundColor: '#fff', borderRadius: 100, borderWidth: 1, borderColor: 'grey', padding: 10 }} >
                                    <Image source={ImagePath.TRACKER_COMPLETED} />
                                </View>
                            }
                            {this.state.trackerData.req_status == 3 ?
                                <View style={{ position: 'absolute', marginTop: 230, justifyContent: 'center', backgroundColor: Colors.SKY_BLUE_BUTTON_BACKGROUND, borderRadius: 100, borderWidth: 1, borderColor: 'grey', padding: 10 }} >
                                    <Image source={ImagePath.TRACKER_BOOKED} />
                                </View> :
                                <View style={{ position: 'absolute', marginTop: 230, justifyContent: 'center', backgroundColor: '#fff', borderRadius: 100, borderWidth: 1, borderColor: 'grey', padding: 10 }} >
                                    <Image source={ImagePath.TRACKER_BOOKED} />
                                </View>
                            }

                            {this.state.trackerData.req_status == 2 ?
                                <View style={{ position: 'absolute', marginTop: 335, justifyContent: 'center', backgroundColor: Colors.SKY_BLUE_BUTTON_BACKGROUND, borderRadius: 100, borderWidth: 1, borderColor: 'grey', padding: 10 }} >
                                    <Image source={ImagePath.TAG_ACCEPTED} />
                                </View> :
                                <View style={{ position: 'absolute', marginTop: 335, justifyContent: 'center', backgroundColor: '#fff', borderRadius: 100, borderWidth: 1, borderColor: 'grey', padding: 10 }} >
                                    <Image source={ImagePath.TAG_ACCEPTED} />
                                </View>
                            }
                            {this.state.trackerData.req_status == 1 ?
                                <View style={{ position: 'absolute', marginTop: 440, justifyContent: 'center', backgroundColor: Colors.SKY_BLUE_BUTTON_BACKGROUND, borderRadius: 100, borderWidth: 1, borderColor: 'grey', padding: 10 }} >
                                    <Image source={ImagePath.PAPER_PLANE_SENT} />
                                </View>
                                :
                                <View style={{ position: 'absolute', marginTop: 440, justifyContent: 'center', backgroundColor: Colors.WHITE, borderRadius: 100, borderWidth: 1, borderColor: 'grey', padding: 10 }} >
                                    <Image source={ImagePath.PAPER_PLANE_SENT} />
                                </View>
                            }
                        </View>
                    </View>

                    <View style={{ width: 300, alignItems: 'flex-start' }}>
                        {this.state.trackerData.req_status == 5 ? <View style={{ position: 'absolute', left: 25, marginTop: 40, justifyContent: 'center', }} >
                            <Text style={{ fontSize: 18, fontWeight: 'bold', color: Colors.SKY_BLUE_BUTTON_BACKGROUND }}>Confirmed</Text>

                        </View>
                            : <View style={{ position: 'absolute', left: 25, marginTop: 40, justifyContent: 'center', }} >
                                <Text style={{ fontSize: 18, fontWeight: 'bold' }}>Confirmed</Text>

                            </View>
                        }

                        {this.state.trackerData.req_status == 4 ?
                            <View style={{ position: 'absolute', left: 25, marginTop: 140, justifyContent: 'center', }} >
                                <Text style={{ fontSize: 18, fontWeight: 'bold', color: Colors.SKY_BLUE_BUTTON_BACKGROUND }}>Completed</Text>

                            </View>
                            : <View style={{ position: 'absolute', left: 25, marginTop: 140, justifyContent: 'center', }} >
                                <Text style={{ fontSize: 18, fontWeight: 'bold' }}>Completed</Text>

                            </View>
                        }
                        {this.state.trackerData.req_status == 3 ? <View style={{ position: 'absolute', left: 25, marginTop: 240, justifyContent: 'center', }} >
                            <Text style={{ fontSize: 18, fontWeight: 'bold', color: Colors.SKY_BLUE_BUTTON_BACKGROUND }}>Booked</Text>

                        </View>
                            : <View style={{ position: 'absolute', left: 25, marginTop: 240, justifyContent: 'center', }} >
                                <Text style={{ fontSize: 18, fontWeight: 'bold' }}>Booked</Text>

                            </View>
                        }

                        {this.state.trackerData.req_status == 2 ? <View style={{ position: 'absolute', left: 25, marginTop: 345, justifyContent: 'center', }} >
                            <Text style={{ fontSize: 18, fontWeight: 'bold', color: Colors.SKY_BLUE_BUTTON_BACKGROUND }}>Accepted</Text>

                        </View>
                            : <View style={{ position: 'absolute', left: 25, marginTop: 345, justifyContent: 'center', }} >
                                <Text style={{ fontSize: 18, fontWeight: 'bold' }}>Accepted</Text>

                            </View>
                        }
                        {this.state.trackerData.req_status == 1 ?

                            <View style={{ position: 'absolute', left: 25, marginTop: 450, justifyContent: 'center', }} >
                                <Text style={{ fontSize: 18, fontWeight: 'bold', color: Colors.SKY_BLUE_BUTTON_BACKGROUND }}>Sent</Text>

                            </View>
                            : <View style={{ position: 'absolute', left: 25, marginTop: 450, justifyContent: 'center', }} >
                                <Text style={{ fontSize: 18, fontWeight: 'bold' }}>Sent</Text>

                            </View>
                        }

                    </View>
                </View>
            </ScrollView>

        );
    }
}

export default TrackerScreen;
